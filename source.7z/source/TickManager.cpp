#include "TickManager.h"
#include "client/TwsClientSync.h"

#define WorkerPtr if( auto p=TickWorker::Instance(); p ) p
#define TwsClientPtr if( _pTwsClient ) _pTwsClient
#define var const auto

namespace Jde::Markets
{

	void TickManager::Subscribe( uint hClient, ContractPK contractId, const flat_set<ETickList>& fields, bool snapshot, ProtoFunction fnctn )noexcept
	{
		WorkerPtr->Subscribe( hClient, contractId, fields, snapshot, fnctn );
	}

	void TickManager::CalcImpliedVolatility( uint hClient, const ::Contract& contract, double optionPrice, double underPrice, ProtoFunction fnctn )noexcept
	{
		WorkerPtr->CalcImpliedVolatility( hClient, contract, optionPrice, underPrice, fnctn );
	}

	void TickManager::CalculateOptionPrice( uint hClient, const ::Contract& contract, double volatility, double underPrice, ProtoFunction fnctn )noexcept
	{
		WorkerPtr->CalculateOptionPrice( hClient, contract, volatility, underPrice, fnctn );
	}

	void TickManager::CancelProto( uint hClient, ContractPK contractId )noexcept
	{
		WorkerPtr->CancelProto( hClient, contractId );
	}

	std::future<Tick> TickManager::Ratios( const ContractPK contractId )noexcept
	{
		auto p=TickWorker::Instance();
		if( !p )
			THROW( Exception("Shutting Down") );
		return p->Ratios( contractId );
	}

	void TickManager::Cancel( Coroutine::Handle h )noexcept
	{
		WorkerPtr->Cancel( h );
	}

	TickManager::Awaitable::Awaitable( const TickParams& params, Coroutine::Handle& h )noexcept:
		Coroutine::CancelAwaitable{ h },
		TickParams{ params }
	{}

	void TickManager::Awaitable::await_suspend( Awaitable::Handle h )noexcept
	{
		_pPromise = &h.promise();
		WorkerPtr->Subscribe( TickWorker::SubscriptionInfo{ {h, _hClient}, *this} );
	}
	bool TickManager::Awaitable::await_ready()noexcept
	{
		auto p=TickWorker::Instance();
		return p && p->Test( TickValue, Fields );
	}

	TickManager::TickWorker::TickWorker()noexcept(false):
		base{"TickWorker"},
		_pTwsClient{ static_pointer_cast<TwsClientSync>(TwsClientSync::InstancePtr()) }
	{
		if( !_pTwsClient )
			THROW( Exception("Not connected to Tws") );
	}

	optional<Tick> TickManager::TickWorker::Get( ContractPK contractId )const noexcept
	{
		shared_lock l{ _valuesMutex };
		auto p = _values.find( contractId );
		return p==_values.end() ? optional<Tick>{} : p->second;
	}
	TickerId TickManager::TickWorker::RequestId( ContractPK contractId )const noexcept
	{
		shared_lock l{ _tickerContractMapMutex };
		var p = std::find_if( _tickerContractMap.begin(), _tickerContractMap.end(), [contractId](auto x){return contractId==x.second;} );
		return p==_tickerContractMap.end() ? 0 : p->second;
	}
	bool TickManager::TickWorker::Test( Tick& clientTick, TickFields fields )const noexcept
	{
		var tick = Get( clientTick.ContractId );
		return tick && TickManager::TickWorker::Test( clientTick, fields, tick.value() );
	}

	bool TickManager::TickWorker::Test( Tick& clientTick, TickFields clientFields, const Tick& latestTick )const noexcept
	{
		bool haveUpdate = false;
		for( uint i = 0; clientFields.any() && i < clientFields.size() && !haveUpdate; ++i )
		{
			if( !clientFields[i] )
				continue;
			clientFields.reset( i );
			var tickType = (ETickType)i;
			haveUpdate = latestTick.IsSet(tickType) && !clientTick.FieldEqual( latestTick, tickType );
		}
		if( haveUpdate )
			clientTick = latestTick;
		return haveUpdate;
	}

	void TickManager::TickWorker::Push( TickerId tickerId, ETickType tickType, function<void(Tick&)> fnctn )noexcept
	{
		auto contractId = ContractId( tickerId );
		if( contractId )
		{
			shared_lock l( _valuesMutex );
			if( auto pValue=_values.find(contractId); pValue!=_values.end() )
			{
				fnctn( pValue->second );
				AddOutgoingField( contractId, tickType );
			}
		}
		else if( _canceledTicks.emplace(tickerId) )
		{
			WARN( "Could not find contract for ticker {}"sv, tickerId );
			TwsClientPtr->cancelMktData( tickerId );
		}
	}
	void TickManager::TickWorker::Push( TickerId id, ETickType type, double v )noexcept
	{
		Push( id, type, [type,v](Tick& tick){ tick.SetDouble( type, v );} );
	}

	void TickManager::TickWorker::PushPrice( TickerId id, ETickType type, double v/*, const TickAttrib& attribs*/ )noexcept
	{
		Push( id, type, [type,v](Tick& tick){ tick.SetPrice(type, v/*, attribs*/);} );
	}
	void TickManager::TickWorker::Push( TickerId id, ETickType type, int v )noexcept
	{
		Push( id, type, [type,v](Tick& tick){ tick.SetInt(type, v);} );
	}
	void TickManager::TickWorker::Push( TickerId id, ETickType type, const std::string& v )noexcept
	{
		Push( id, type, [type,v](Tick& tick){ tick.SetString(type, v);} );
	}
	void TickManager::TickWorker::Push( TickerId id, time_t timeStamp, const std::string& providerCode, const std::string& articleId, const std::string& headline, const std::string& extraData )noexcept
	{
		Push( id, type, [type,v](Tick& tick){ tick.SetString(type, v);} );
	}

	void TickManager::TickWorker::Push( TickerId id, ETickType type, int tickAttrib, double impliedVol, double delta, double optPrice, double pvDividend, double gamma, double vega, double theta, double undPrice )noexcept
	{
		Proto::Results::MessageUnion msg;
		if( auto p = _optionRequests.find(id); p!=_optionRequests.end() )
		{
			var handle = get<0>( p->second );
			const uint32_t clientId = (uint32_t)handle;
			const uint32_t sessionId = (uint32_t)(handle >> 32);
			msg.set_allocated_option_calculation( OptionComputation{ tickAttrib==0, impliedVol, delta, optPrice, pvDividend, gamma, vega, theta, undPrice }.ToProto(clientId, type).release() );
			unique_lock l{ _optionRequestMutex };
			get<1>( p->second )( {msg}, sessionId );
			_optionRequests.erase( p );
		}
		else
			WARN( "({})Could not find option request"sv, id );
	}

	void TickManager::TickWorker::Process()noexcept
	{
		optional<tuple<Tick,TickFields>> outgoing;
		{
			unique_lock l{_outgoingFieldsMutex};
			if( auto p=_outgoingFields.begin(); p!=_outgoingFields.end() )
			{
				shared_lock l{_valuesMutex};
				if( auto pValue = _values.find(p->first); pValue!=_values.end() )
					outgoing = make_tuple( pValue->second, p->second );
				else
					CRITICAL( "Could not find contract {} in values."sv, p->first );
				_outgoingFields.erase( p );
			}
		}
		if( outgoing )
		{
			var& tick = get<0>( outgoing.value() );
			var& fields = get<1>( outgoing.value() );
			var contractId = tick.ContractId;
			bool haveSubscription = false;
			{//coroutine Subscriptions
				unique_lock l{ _subscriptionMutex };
				auto range = _subscriptions.equal_range( contractId );
				for( auto p = range.first; p!=range.second; )
				{
					auto& params = p->second.Params;
					auto& clientTick = params.TickValue;
					auto clientFields = params.Fields;
					if( Test(clientTick, clientFields, tick) )
					{
						auto h = p->second.HCoroutine;
						l.unlock();
						h.promise().get_return_object().result = tick;
						h.resume();//TODO put in another thread.
						p = _subscriptions.erase( p );

						unique_lock l2{ _delayMutex };
						_delays.emplace( Clock::now()+3s, make_tuple(ESubscriptionSource::Coroutine, p->second.HClient, contractId) );
					}
					else
						haveSubscription = true;
				}
			}
			{//Proto Subscriptions
				unique_lock l{ _protoSubscriptionMutex };
				auto range = _protoSubscriptions.equal_range( contractId );
				for( auto p = range.first; p!=range.second; ++p )
				{
					haveSubscription = true;
					auto f = fields;
					vector<const Proto::Results::MessageUnion> messages;
					for( uint i = 0; f.any() && i < f.size(); ++i )
					{
						if( !f[i] )
							continue;
						f.reset( i );

						messages.push_back( tick.ToProto((ETickType)i) );
					}
					get<1>(p->second)( messages, contractId );
				}
			}
			{//Ratio Subscriptions
				unique_lock l{ _ratioSubscriptionMutex };
				auto range = _ratioSubscriptions.equal_range( contractId );
				for( auto p = range.first; p!=range.second; ++p )
				{
					if( tick.HasRatios() )
					{
						get<0>(p->second).set_value( tick );
						_ratioSubscriptions.erase( p );
						RemoveTwsSubscription( ESubscriptionSource::Internal, get<2>(p->second), contractId );
					}
					else
						haveSubscription = true;
				}
			}
			LastOutgoing = Clock::now();
			if( !haveSubscription && std::find_if(_orphans.begin(), _orphans.end(), [&tick](auto x){return tick.ContractId==x.second;})==_orphans.end() )
				_orphans.emplace( Clock::now()+3s, tick.ContractId );  //TODO subscribe/unsubscribe from twsclient
		}
		{//ratio timeouts
			unique_lock l{ _ratioSubscriptionMutex };
			for( auto p = _ratioSubscriptions.begin(); p!=_ratioSubscriptions.end(); )
			{
				auto& value = p->second;
				if( get<1>(value)>Clock::now() )
					++p;
				else
				{
					get<0>(value).set_exception( std::make_exception_ptr(Exception("Timeout")) );
					unique_lock l{ _ratioSubscriptionMutex };
					RemoveTwsSubscription( ESubscriptionSource::Internal, get<2>(p->second), p->first );
					p = _ratioSubscriptions.erase( p );
				}
			}
		}
		{
			unique_lock l2{ _delayMutex };
			for( auto p = _delays.begin(); p!=_delays.end() && p->first<Clock::now(); )
			{
				var value = p->second;
				RemoveTwsSubscription( get<0>(value), get<1>(value), get<2>(value) );
				p = _delays.erase( p );
			}
		}
		{//orphans
			unique_lock l{ _orphanMutex };
			for( auto p = _orphans.begin(); p!=_orphans.end() && p->first<Clock::now(); )
			{
				//haveSubscription = p->second==tick.ContractId;//don't need to add it again to _orphans.
				if( var requestId = RequestId(p->second); requestId )//TODO remove from other collections.
				{
					DBG( "({})Canceling orphan contract={}"sv, requestId, p->second );
					TwsClientPtr->cancelMktData( requestId );//TODO clear set fields, remove from subscription maps.
				}
				else
					DBG( "Could not find tick for orphan contract={}"sv, p->second );

				p = _orphans.erase( p );
			}
		}

		if( LastOutgoing-Clock::now()<WakeDuration )
			std::this_thread::yield();
		else
		{
			std::unique_lock<std::mutex> lk( _mtx );//TODO trigger _cv when pushing
			_cv.wait_for( lk, WakeDuration );
		}
	}
	flat_set<ETickList> TickManager::TickWorker::GetSubscribedTicks( ContractPK id )const noexcept
	{
		flat_set<ETickList> ticks;
		auto range = _twsSubscriptions.equal_range( id );
		for( auto p=range.first; p!=range.second; ++p )//TODO only remove from _twsSubscriptions when canceling.
			ticks.insert( p->second.Ticks.begin(), p->second.Ticks.end() );
		return ticks;
	}
	void TickManager::TickWorker::RemoveTwsSubscription( ESubscriptionSource source, uint id, ContractPK contractId )noexcept
	{
		unique_lock	l{ _twsSubscriptionMutex };
		flat_set<ETickList> previousTicks;
		auto range = _twsSubscriptions.equal_range( contractId );
		auto p = range.first, pFound = range.second;
		for( ; p!=range.second; ++p )
		{
			var itemSource = p->second;
			previousTicks.insert( itemSource.Ticks.begin(), itemSource.Ticks.end() );
			if( itemSource.Source==source && itemSource.Id==id )
				pFound = p;
		}
		if( pFound!=range.second )
		{
			_twsSubscriptions.erase( pFound );
			var currentTicks = GetSubscribedTicks( contractId );
			var requestId = RequestId( contractId );
			if( !requestId )
				WARN( "Lost requestId for contract '{}'"sv, contractId );
			if( requestId && currentTicks.size()<previousTicks.size() )
			{
				_pTwsClient->cancelMktData( requestId );
				if( currentTicks.size() )
				{
					var newRequestId = _pTwsClient->RequestId();//TODO save newRequestId
					//var details = _pTwsClient->ReqContractDetails( contractId ).get();
					::Contract contract; contract.conId = contractId;
					_pTwsClient->reqMktData( newRequestId, contract, StringUtilities::AddCommas(currentTicks), false, false, {} );
				}
			}
		}
		else
			WARN( "Lost request for contract '{}'"sv, contractId );
	}
	void TickManager::TickWorker::Cancel( Coroutine::Handle h )noexcept
	{
		//TODO unsubscribe
		unique_lock l{ _subscriptionMutex };
		if( auto p = std::find_if(_subscriptions.begin(), _subscriptions.end(), [h](var x){ return x.second.HClient==h;}); p!=_subscriptions.end() )
		{
			DBG( "Cancel({})"sv, h );

			p->second.HCoroutine.destroy();
			_subscriptions.erase( p );
		}
		else
			DBG( "Could not find handle {}."sv, h );
	}
	void TickManager::TickWorker::CancelProto( uint hClient, ContractPK contractId )noexcept
	{
		_delays.emplace( Clock::now()+3s, make_tuple(ESubscriptionSource::Proto, hClient, contractId) );

		unique_lock l{ _protoSubscriptionMutex };
		auto range = _protoSubscriptions.equal_range( contractId );
		auto p = std::find_if( range.first, range.second, [hClient](auto x){ return get<0>(x.second)==hClient; } );
		if( p!=range.second )
			_protoSubscriptions.erase( p );
		else
			DBG( "Could not find proto contractId={} hClient={}"sv, contractId, hClient );
	}

	#define PREFIX auto pTwsClient = _pTwsClient; if( !pTwsClient ) return; var id = pTwsClient->RequestId(); unique_lock l{ _optionRequestMutex }; _optionRequests.emplace( id, make_tuple(hClient, fnctn) );
	void TickManager::TickWorker::CalcImpliedVolatility( uint hClient, const ::Contract& contract, double optionPrice, double underPrice, ProtoFunction fnctn )noexcept
	{
		PREFIX
		pTwsClient->calculateImpliedVolatility( id, contract, optionPrice, underPrice, {} );
	}
	void TickManager::TickWorker::CalculateOptionPrice( uint hClient, const ::Contract& contract, double volatility, double underPrice, ProtoFunction fnctn )noexcept
	{
		PREFIX
		pTwsClient->calculateOptionPrice( id, contract, volatility, underPrice, {} );
	}

	std::future<Tick> TickManager::TickWorker::Ratios( const ContractPK contractId )noexcept
	{
		auto pTwsClient = _pTwsClient;
		var tick = Get( contractId );
		if( tick && tick.value().HasRatios() )
		{
			std::promise<Tick> promise;
			promise.set_value( tick.value() );
			return promise.get_future();
		}
		//don't already have.
		unique_lock	l{ _twsSubscriptionMutex };
		flat_set<ETickList> requestTicks = GetSubscribedTicks( contractId );

		const flat_set ticks{ ETickList::MiscStats, ETickList::Fundamentals, ETickList::Dividends };
		var handle = ++InternalSubscriptionHandle;
		AddSubscription( contractId, TickListSource{ESubscriptionSource::Internal, handle, ticks} );

		auto p = _ratioSubscriptions.emplace( contractId, make_tuple( std::promise<Tick>{}, Clock::now()+5s, handle ) );
		return get<0>( p->second ).get_future();
	}

	void TickManager::TickWorker::AddSubscription( ContractPK contractId, const TickListSource& source )noexcept
	{
		unique_lock	l{ _twsSubscriptionMutex };
		auto requestTicks = GetSubscribedTicks( contractId );
		auto newTicks = 0;
		for_each( source.Ticks.begin(), source.Ticks.end(), [&newTicks, &requestTicks](auto x){newTicks+=requestTicks.emplace(x).second;} );
		_twsSubscriptions.emplace( contractId, source );
		l.unlock();
		if( newTicks )
		{
			var currentRequestId = requestTicks.size()>source.Ticks.size() ? RequestId( contractId ) : 0;
			if( currentRequestId )
				_pTwsClient->cancelMktData( currentRequestId );

			var reqId = _pTwsClient->RequestId();
			::Contract contract;  contract.conId = contractId; contract.exchange = "SMART";
			_pTwsClient->reqMktData( reqId, contract, StringUtilities::AddCommas(requestTicks), false, false, {} );//456=dividends - https://interactivebrokers.github.io/tws-api/tick_types.html
		}
	}

	void TickManager::TickWorker::Subscribe( uint hClient, ContractPK contractId, const flat_set<ETickList>& fields, bool snapshot, ProtoFunction fnctn )noexcept
	{
		{
			unique_lock l{ _protoSubscriptionMutex };
			_protoSubscriptions.emplace( contractId, make_tuple(hClient,fnctn) );
		}
		AddSubscription( contractId, TickListSource{ESubscriptionSource::Proto, hClient, fields} );
	}
	void TickManager::TickWorker::Subscribe( const SubscriptionInfo& subscription )noexcept
	{
		var& params = subscription.Params;
		var contractId = params.TickValue.ContractId;
		{
			unique_lock l{ _subscriptionMutex };
			_subscriptions.emplace( contractId, subscription );
		}
		AddSubscription( contractId, TickListSource{ESubscriptionSource::Coroutine, subscription.HClient, {ETickList::PlPrice}} );
	}
}