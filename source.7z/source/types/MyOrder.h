#pragma once
#include <Order.h>
#include <CommonDefs.h>
#include <OrderState.h>
#include "../Exports.h"
#include "proto/ib.pb.h"
#include "proto/results.pb.h"

namespace Jde::Markets
{
	using Proto::Results::EOrderStatus;
	namespace Proto
	{
		namespace Results{ class OrderState; }
		namespace IB{ enum ETimeInForce:int; class Order; }
	}

	struct JDE_MARKETS_EXPORT MyOrder : public ::Order
	{
		MyOrder()noexcept=default;
		MyOrder( ::OrderId orderId, const Proto::Order& order )noexcept;
		MyOrder( const ::Order& order )noexcept:Order{order}{}

		bool IsBuy()const noexcept{ return action=="BUY"; } void IsBuy( bool value )noexcept{ action = value ? "BUY" : "SELL"; }
		Proto::ETimeInForce TimeInForce()const noexcept; void TimeInForce( Proto::ETimeInForce value )noexcept;
		Proto::EOrderType OrderType()const noexcept; void OrderType( Proto::EOrderType value )noexcept;
		sp<Proto::Order> ToProto( bool stupidPointer=false )const noexcept;
		static time_t ParseDateTime( const string& date )noexcept;
		static string ToDateString( time_t date )noexcept;
		static Proto::Results::OrderState* ToAllocatedProto( const ::OrderState& state )noexcept;

		enum class Fields : uint
		{
			None        = 0,
			LastUpdate 	= 1 << 1,
			Limit 		= 1 << 2,
			Quantity    = 1 << 3,
			Action 		= 1 << 4,
			Type	 		= 1 << 5,
			Aux	 		= 1 << 6,
			Transmit		= 1 << 7,
			Account		= 1 << 8,
		};
		Fields Changes( const MyOrder& status, Fields fields )const noexcept;
		TimePoint LastUpdate;
	};
	inline MyOrder::Fields operator|(MyOrder::Fields a, MyOrder::Fields b){ return (MyOrder::Fields)( (uint)a | (uint)b ); }
	inline MyOrder::Fields operator|=(MyOrder::Fields& a, MyOrder::Fields b){ return a = (MyOrder::Fields)( (uint)a | (uint)b ); }

	struct OrderStatus final
	{
		::OrderId Id;
		EOrderStatus Status{EOrderStatus::None};
		double Filled;
		double Remaining;
		double AverageFillPrice;
		int32 PermId;
		int32 ParentId;
		double LastFillPrice;
		string WhyHeld;
		double MarketCapPrice;

		enum class Fields : uint8
		{
			None = 0,
			Status      = 1 << 1,
			Filled      = 1 << 2,
			Remaining   = 1 << 3,
			All = std::numeric_limits<uint8>::max()
		};
		Fields Changes( const OrderStatus& status, Fields fields )const noexcept;
	};
	inline OrderStatus::Fields operator|(OrderStatus::Fields a, OrderStatus::Fields b){ return (OrderStatus::Fields)( (uint8)a | (uint8)b ); }
	inline OrderStatus::Fields operator|=(OrderStatus::Fields& a, OrderStatus::Fields b){ return a = (OrderStatus::Fields)( (uint)a | (uint)b ); }

	struct OrderState : ::OrderState
	{
		OrderState():
			::OrderState{}
		{}
		OrderState( const ::OrderState& base ):
			::OrderState{base}
		{}

		enum class Fields : uint8
		{
			None            = 0,
			Status          = 1 << 1,
			CompletedTime   = 1 << 2,
			CompletedStatus = 1 << 3,
			All = std::numeric_limits<uint8>::max()
		};
		Fields Changes( const OrderState& state, Fields fields )const noexcept;
	};
	inline OrderState::Fields operator| (OrderState::Fields a, OrderState::Fields b){ return (OrderState::Fields)( (uint8)a | (uint8)b ); }
	inline OrderState::Fields operator|=(OrderState::Fields& a, OrderState::Fields b){ return a = (OrderState::Fields)( (uint)a | (uint)b ); }
}